import java.util.Scanner;
class Box{
double width,height,depth;
Box(double w,double h,double d){
height=h;
width=w;
depth=d;
}
public double Volume(){
return width*height*depth;
}
}
class Pgm1{
public static void main(String[] args){
Scanner s=new Scanner(System.in);
double a1=s.nextDouble();
double a2=s.nextDouble();
double a3=s.nextDouble();
Box b=new Box(a1,a2,a3);
System.out.println("volume : "+b.Volume());
}
}