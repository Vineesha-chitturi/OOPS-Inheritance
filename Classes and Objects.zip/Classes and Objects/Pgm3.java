import java.util.Scanner;
class Patient{
String patientName;
double height;
double weight;
Patient(double h,double w){
height=h;
weight=w;
}
public double computeBMI(){
return  (weight/(height*height));
}
}
class Pgm3{
public static void main(String[] args){
Scanner s=new Scanner(System.in);
double a1=s.nextDouble();
double a2=s.nextDouble();
Patient p=new Patient(a1,a2);
System.out.println("BMI : "+p.computeBMI());
}
}