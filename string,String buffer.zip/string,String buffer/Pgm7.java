import java.util.Scanner;
class Pgm7{
public static void main(String args[]){
Scanner s=new Scanner(System.in);
String s1=s.nextLine();
int l=s1.length();
if(s1.charAt(0)=='x'&&s1.charAt(l-1)=='x'){
System.out.println(s1.substring(1,l-1));}
else if(s1.charAt(0)=='x'){System.out.println(s1.substring(1,l));}
else if(s1.charAt(l-1)=='x'){System.out.println(s1.substring(0,l-1));}
else{System.out.println(s1);}
}
}