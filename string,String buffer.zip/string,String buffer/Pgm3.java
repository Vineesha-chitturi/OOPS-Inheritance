import java.util.Scanner;
class Pgm3{
public static void main(String args[]){
Scanner s=new Scanner(System.in);
String s1=s.nextLine();
int l=s1.length();
for(int i=0;i<l;i++)
{System.out.print(s1.substring(0,2));}
}
}