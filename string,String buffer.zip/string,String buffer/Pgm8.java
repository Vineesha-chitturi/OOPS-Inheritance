import java.lang.*;
import java.util.*;
public class Pgm8 {
public static void main(String[] args) {
Scanner s=new Scanner(System.in);
String s1=s.nextLine();
int l=s1.length();
int n=s1.indexOf('*');
System.out.println(s1.substring(0,n-1)+s1.substring(n+2,l));
}
}