import java.lang.*;
import java.util.*;
public class Pgm1 {
public static void main(String[] args) {
Scanner s=new Scanner(System.in);
String s1=s.nextLine();
String s2="";
int l=s1.length();
for(int i=l-1;i>=0;i--){
s2=s2+s1.charAt(i);
}
if(s1.equals(s2)==true){System.out.println("Palindrome");}
else{System.out.println("not Palindrome");}
}
}