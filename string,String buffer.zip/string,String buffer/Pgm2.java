import java.lang.*;
import java.util.*;
public class Pgm2 {
public static void main(String[] args) {
Scanner s=new Scanner(System.in);
String s1=s.nextLine();
String[] str=s1.split(",");
int l1=str[0].length();
int l2=str[1].length();
if(str[0].charAt(l1-1)==str[1].charAt(0)){System.out.println(str[0]+str[1].substring(1,l1));}
else{
System.out.println(str[0]+str[1]);
}
}
}