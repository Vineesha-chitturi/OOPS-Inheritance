import java.util.Scanner;
class Pgm5{
public static void main(String args[]){
Scanner s=new Scanner(System.in);
String s1=s.nextLine();
int l=s1.length();
System.out.println(s1.substring(1,l-1));
}
}