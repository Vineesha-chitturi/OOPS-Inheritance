import java.util.Scanner;
class Pgm4{
public static void main(String args[]){
Scanner s=new Scanner(System.in);
String s1=s.nextLine();
int l=s1.length();
if(l%2==0){System.out.println(s1.substring(0,l/2));}
else{System.out.println("null");}
}
}