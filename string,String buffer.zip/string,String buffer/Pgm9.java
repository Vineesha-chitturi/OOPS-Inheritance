import java.lang.*;
import java.util.*;
public class Pgm9 {
public static void main(String[] args) {
Scanner n=new Scanner(System.in);
String s=n.nextLine();
String[] s1=s.split(",");

StringBuilder result = new StringBuilder(); 
for (int i = 0; i < s1[0].length() || i < s1[1].length(); i++) {
if (i < s1[0].length()) 
result.append(s1[0].charAt(i)); 
if (i < s1[1].length()) 
result.append(s1[1].charAt(i)); 
} 
System.out.println(result.toString());
}
}