class Fruit{
String name;
String taste;
double size;
public void eat(){
System.out.println(".......");
}}
class Apple extends Fruit{
public void eat()
{System.out.println("Apple is sweet");}
}
class Orange extends Fruit{
public void eat(){
System.out.println("Orange is sweet");
}
}
class Pgm1{
public static void main(String args[]){
Apple a= new Apple();
a.eat();
Orange o=new Orange();
o.eat();
}
}