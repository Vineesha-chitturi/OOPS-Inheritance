class Shape{
public void draw(){
System.out.println("drawing......");
}
public void erase(){
System.out.println("erasing.........");
}
}
class Circle extends Shape{
public void draw(){
System.out.println("drawing circle");
}
public void erase(){
System.out.println("erasing circle");
}
}
class Triangle extends Shape{
public void draw(){
System.out.println("drawing triangle");
}
public void erase(){
System.out.println("erasing triangle");
}
}
class Square extends Shape{
public void draw(){
System.out.println("drawing square");
}
public void erase(){
System.out.println("erasing square");
}
}
class Pgm2{
public static void main(String args[]){
Circle c= new Circle();
Triangle t=new Triangle();
Square s=new Square();
c.draw();
t.draw();
s.draw();
c.erase();
t.erase();
s.erase();
}
}
