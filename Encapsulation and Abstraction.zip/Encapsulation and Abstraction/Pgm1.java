class Author{
private String name;
private String email;
private char gender;
Author(String name,String email,char g){
this.name=name;
this.email=email;
gender=g;
}
String getName()
{return name;}
String getEmail()
{return email;}
char getGender()
{return gender;}
}
class Book{
private String name;
private Author author;
private double price;
private int qtyInStock;
Book(String name,Author author,double p,int q){
this.name=name;
this.author=author;
price=p;
qtyInStock=q;
}
String getName()
{return name;}
Author getAuthor()
{return author;}
double getPrice()
{return price;}
int getqtyInStock()
{return qtyInStock;}
void setPrice(double p){
this.price=p;
}
void setqtyInStock(int q){
this.qtyInStock=q;
}
}
class Pgm1{
public static void main(String args[])
{
Author a=new Author("VIN","vin@gmail.com",'F');
Book b=new Book("Encapsulation and Abstraction",a,2000,1);
System.out.println("Name of the book is : "+b.getName());
System.out.println("Author :"+b.getAuthor()+"\n"+"Gender :"+a.getGender()+"\n"+"Price :"+b.getPrice()+"\n"+"Stock : "+b.getqtyInStock());
}
}
