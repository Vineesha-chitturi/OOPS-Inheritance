class Person{
String name;
String dob;
}
class Student extends Person{
int studentid;
}
class Teacher extends Person{
double salary;
String subject;
Teacher(String n,String db,double s,String sub){
name=n;
salary=s;
subject=sub;
dob=db;
}
void display(){
System.out.println("Name :"+name+"\n"+"Date of birth :"+dob+"salary : "+salary+"\n"+"Subject : "+subject);
}
}
class CollegeStudent extends Student{
String clgname;
int year;
CollegeStudent(String n,String db,int id,String cn,int y){
name=n;
studentid=id;
clgname=cn;
year=y;
dob=db;
}
void display(){
System.out.println("Name :"+name+"\n"+"Date of birth :"+dob+"studentid : "+studentid+"\n"+"Collegename : "+clgname+"\n"+"Year :"+year);
}
}
class Pgm3{
public static void main(String args[]){
Teacher t=new Teacher("Vas","20-03-1972",10000,"Math");
CollegeStudent c=new CollegeStudent("Vin","30-08-1999",1234,"SRKR",4);
System.out.println("Teacher Details..................................");
t.display();
System.out.println("Student Details..................................");
c.display();
}
}