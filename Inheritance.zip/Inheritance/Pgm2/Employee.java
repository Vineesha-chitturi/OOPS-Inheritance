class Employee extends Person{
double annualsalary;
int startingyear;
String insnumber;
Employee(){
name="UNKNOWN";
annualsalary=1000000;
startingyear=2019;
insnumber="0123456";
}
Employee(String name,double salary,int year,String insnum){
this.name=name;
annualsalary=salary;
startingyear=year;
insnumber=insnum;
}
String getName(){return name;}
double getSalary(){return annualsalary;}
int getYear(){return startingyear;}
String getInsNum(){return insnumber;}
}