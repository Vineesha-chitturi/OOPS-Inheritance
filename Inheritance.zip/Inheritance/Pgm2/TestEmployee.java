class TestEmployee{
public static void main(String args[]){
Employee e=new Employee("Vin",500000,2019,"0123456");
System.out.println("Name of the employee : "+e.getName());
System.out.println("Annual salary : "+e.getSalary());
System.out.println("Year of starting : "+e.getYear());
System.out.println("Insurance number : "+e.getInsNum());
}
}