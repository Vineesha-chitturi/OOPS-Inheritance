class Person{
String name;
}